`timescale 1ns/1ps
module tb;
localparam R=12, C=10, K=128, AW=$clog2(K), LW=$clog2(K+1);
reg clk=0,rst=1,a_we=0,b_we=0,start=0,clear_before=1;
reg [AW-1:0] a_waddr=0,b_waddr=0;
reg [R*8-1:0] a_wdata=0; reg [C*8-1:0] b_wdata=0;
reg [LW-1:0] k_len=0; wire busy,done; wire [R*C*32-1:0] acc_flat;
reg signed [31:0] expected [0:R*C-1];
integer trial,t,r,c,len;
kernellum_gemm_engine #(.ROWS(R),.COLS(C),.K_TILE(K),.ACC_WIDTH(32)) dut(.*);
always #5 clk=~clk;
function integer av(input integer x,y,z);
begin av=((x*37+y*13+z*59)%256)-128; end endfunction
function integer bv(input integer x,y,z);
begin bv=((x*71+y*29+z*17)%256)-128; end endfunction
initial begin #1000000; $fatal(1,"TIMEOUT"); end
initial begin
 repeat(3) @(negedge clk); rst=0;
 for(trial=0;trial<3;trial=trial+1) begin
  len=(trial==0)?K:((trial==1)?7:1);
  clear_before=(trial!=1);
  if(clear_before) for(r=0;r<R*C;r=r+1) expected[r]=0;
  for(t=0;t<len;t=t+1) begin
   @(negedge clk); a_we=1; b_we=1; a_waddr=t; b_waddr=t;
   for(r=0;r<R;r=r+1) a_wdata[r*8+:8]=av(t,r,trial);
   for(c=0;c<C;c=c+1) b_wdata[c*8+:8]=bv(t,c,trial);
   for(r=0;r<R;r=r+1) for(c=0;c<C;c=c+1)
    expected[r*C+c]=expected[r*C+c]+av(t,r,trial)*bv(t,c,trial);
  end
  @(negedge clk); a_we=0; b_we=0; k_len=len; start=1;
  @(negedge clk); start=0;
  wait(done===1'b1); @(negedge clk);
  for(r=0;r<R*C;r=r+1)
   if($signed(acc_flat[r*32+:32]) !== expected[r]) $fatal(1,"MISMATCH trial=%0d cell=%0d",trial,r);
 end
 $display("KERNELLUM_PILOT_SIM_PASS"); $finish;
end
endmodule
